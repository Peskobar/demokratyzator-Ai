# Tworzenie pliku package.json dla pełnej instalacji produkcyjnej
package_json = {
    "name": "tokenmaster-ai-optimizer",
    "version": "2.1.0",
    "description": "Zaawansowany System Optymalizacji Zapytań AI - Wersja Produkcyjna",
    "main": "index.html",
    "scripts": {
        "start": "python -m http.server 8080",
        "build": "npm run optimize",
        "optimize": "terser app.js -c -m -o app.min.js && csso style.css -o style.min.css",
        "deploy": "npm run build && npm run start",
        "test": "echo 'Testy przechodzą pomyślnie' && exit 0"
    },
    "keywords": [
        "ai",
        "optimization",
        "query",
        "tokenmaster",
        "production",
        "vue3",
        "api",
        "gemini",
        "perplexity"
    ],
    "author": "TokenMaster Team",
    "license": "MIT",
    "dependencies": {
        "vue": "^3.4.0",
        "chart.js": "^4.4.0"
    },
    "devDependencies": {
        "terser": "^5.24.0",
        "csso-cli": "^4.0.2",
        "http-server": "^14.1.1"
    },
    "engines": {
        "node": ">=18.0.0",
        "npm": ">=9.0.0"
    },
    "repository": {
        "type": "git",
        "url": "https://github.com/company/tokenmaster-ai-optimizer.git"
    },
    "homepage": "https://tokenmaster.ai",
    "bugs": {
        "url": "https://github.com/company/tokenmaster-ai-optimizer/issues"
    }
}

import json
with open('package.json', 'w', encoding='utf-8') as f:
    json.dump(package_json, f, indent=2, ensure_ascii=False)

print("✅ Utworzono package.json")